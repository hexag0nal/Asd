class InvestmentModel {
  int? id;
  String asset;
  double amount;
  String currency;
  int timestamp;

  InvestmentModel({this.id, required this.asset, required this.amount, this.currency = 'USD', required this.timestamp});

  Map<String, dynamic> toMap() => {
        'id': id,
        'asset': asset,
        'amount': amount,
        'currency': currency,
        'timestamp': timestamp,
      };

  factory InvestmentModel.fromMap(Map<String, dynamic> m) => InvestmentModel(
        id: m['id'] as int?,
        asset: m['asset'],
        amount: (m['amount'] as num).toDouble(),
        currency: m['currency'],
        timestamp: m['timestamp'],
      );
}
