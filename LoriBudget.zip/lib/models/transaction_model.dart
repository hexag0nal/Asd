class TransactionModel {
  int? id;
  String type; // 'income' or 'expense'
  String category;
  double amount;
  String currency; // e.g. 'TRY', 'USD', 'BTC'
  String note;
  int timestamp; // epoch millis

  TransactionModel({this.id, required this.type, required this.category, required this.amount, this.currency = 'TRY', this.note = '', required this.timestamp});

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'type': type,
      'category': category,
      'amount': amount,
      'currency': currency,
      'note': note,
      'timestamp': timestamp,
    };
  }

  factory TransactionModel.fromMap(Map<String, dynamic> m) {
    return TransactionModel(
      id: m['id'] as int?,
      type: m['type'],
      category: m['category'],
      amount: (m['amount'] as num).toDouble(),
      currency: m['currency'],
      note: m['note'] ?? '',
      timestamp: m['timestamp'],
    );
  }
}
