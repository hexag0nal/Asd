// LoriBudget - main.dart (prototype)
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:loribudget/services/local_db.dart';
import 'package:loribudget/providers/finance_provider.dart';
import 'package:loribudget/screens/dashboard.dart';
import 'package:loribudget/screens/transactions.dart';
import 'package:loribudget/screens/investments.dart';
import 'package:loribudget/screens/settings.dart';
import 'package:loribudget/services/locale_service.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await LocalDb.instance.init(); // initialize local sqlite DB
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => FinanceProvider()),
        ChangeNotifierProvider(create: (_) => LocaleService()),
      ],
      child: Consumer<LocaleService>(
        builder: (context, localeService, _) {
          return MaterialApp(
            debugShowCheckedModeBanner: false,
            title: 'LoriBudget',
            theme: ThemeData.dark().copyWith(
              scaffoldBackgroundColor: const Color(0xFF0B0D10),
              primaryColor: const Color(0xFF1F8A70),
              colorScheme: ColorScheme.dark(
                primary: const Color(0xFF1F8A70),
                secondary: const Color(0xFF2D2F33),
              ),
              appBarTheme: const AppBarTheme(
                backgroundColor: Color(0xFF0F1113),
                elevation: 0,
              ),
            ),
            locale: localeService.locale,
            home: const MainShell(),
          );
        },
      ),
    );
  }
}

class MainShell extends StatefulWidget {
  const MainShell({Key? key}) : super(key: key);

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int _index = 0;
  final _pages = const [
    DashboardScreen(),
    TransactionsScreen(),
    InvestmentScreen(),
    SettingsScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(child: _pages[_index]),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _index,
        backgroundColor: const Color(0xFF0F1113),
        selectedItemColor: const Color(0xFF1F8A70),
        unselectedItemColor: Colors.white70,
        onTap: (i) => setState(() => _index = i),
        items: [
          BottomNavigationBarItem(icon: const Icon(Icons.dashboard), label: LocaleService.t('overview')),
          BottomNavigationBarItem(icon: const Icon(Icons.list_alt), label: LocaleService.t('transactions')),
          BottomNavigationBarItem(icon: const Icon(Icons.show_chart), label: LocaleService.t('investments')),
          BottomNavigationBarItem(icon: const Icon(Icons.settings), label: LocaleService.t('settings')),
        ],
      ),
    );
  }
}
