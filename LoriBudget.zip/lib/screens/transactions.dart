import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:loribudget/providers/finance_provider.dart';
import 'package:loribudget/models/transaction_model.dart';
import 'package:loribudget/services/locale_service.dart';

class TransactionsScreen extends StatefulWidget {
  const TransactionsScreen({Key? key}) : super(key: key);

  @override
  State<TransactionsScreen> createState() => _TransactionsScreenState();
}

class _TransactionsScreenState extends State<TransactionsScreen> {
  final _formKey = GlobalKey<FormState>();
  String _type = 'expense';
  String _category = 'Food';
  double _amount = 0.0;
  String _currency = 'TRY';
  String _note = '';

  final _categories = [
    'Food',
    'Transport',
    'Education',
    'Entertainment',
    'Part-time',
    'Groceries',
    'Other',
  ];

  @override
  Widget build(BuildContext context) {
    final fp = Provider.of<FinanceProvider>(context);
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(LocaleService.t('transactions'), style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        Card(
          color: const Color(0xFF0F1113),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          child: Padding(
            padding: const EdgeInsets.all(12.0),
            child: Form(
              key: _formKey,
              child: Column(children: [
                Row(children: [
                  Expanded(
                    child: DropdownButtonFormField<String>(
                      value: _type,
                      items: const [
                        DropdownMenuItem(value: 'expense', child: Text('Gider')),
                        DropdownMenuItem(value: 'income', child: Text('Gelir')),
                      ],
                      onChanged: (v) => setState(() => _type = v ?? 'expense'),
                      decoration: InputDecoration(labelText: LocaleService.t('quick_add')),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: DropdownButtonFormField<String>(
                      value: _category,
                      items: _categories.map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
                      onChanged: (v) => setState(() => _category = v ?? _categories.first),
                      decoration: InputDecoration(labelText: LocaleService.t('category')),
                    ),
                  ),
                ]),
                const SizedBox(height: 8),
                Row(children: [
                  Expanded(
                    child: TextFormField(
                      decoration: InputDecoration(labelText: LocaleService.t('amount')),
                      keyboardType: TextInputType.numberWithOptions(decimal: true),
                      onSaved: (v) => _amount = double.tryParse(v ?? '0') ?? 0.0,
                      validator: (v) => (v == null || v.isEmpty) ? 'Tutar girin' : null,
                    ),
                  ),
                  const SizedBox(width: 8),
                  SizedBox(
                    width: 100,
                    child: TextFormField(
                      decoration: InputDecoration(labelText: 'CUR'),
                      initialValue: _currency,
                      onSaved: (v) => _currency = v ?? 'TRY',
                    ),
                  ),
                ]),
                const SizedBox(height: 8),
                TextFormField(
                  decoration: InputDecoration(labelText: LocaleService.t('note')),
                  onSaved: (v) => _note = v ?? '',
                ),
                const SizedBox(height: 8),
                Row(mainAxisAlignment: MainAxisAlignment.end, children: [
                  ElevatedButton(
                    onPressed: () async {
                      if (_formKey.currentState!.validate()) {
                        _formKey.currentState!.save();
                        final t = TransactionModel(type: _type, category: _category, amount: _amount, currency: _currency, note: _note, timestamp: DateTime.now().millisecondsSinceEpoch);
                        await fp.addTransaction(t);
                        _formKey.currentState!.reset();
                      }
                    },
                    child: Text(LocaleService.t('add')),
                  )
                ])
              ]),
            ),
          ),
        ),
        const SizedBox(height: 12),
        const Text('Tüm İşlemler', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
        const SizedBox(height: 8),
        Expanded(
          child: fp.loading
              ? const Center(child: CircularProgressIndicator())
              : ListView.builder(
                  itemCount: fp.transactions.length,
                  itemBuilder: (context, i) {
                    final t = fp.transactions[i];
                    return Card(
                      color: const Color(0xFF0E0F11),
                      child: ListTile(
                        leading: Icon(t.type == 'income' ? Icons.arrow_downward : Icons.arrow_upward, color: t.type == 'income' ? Colors.green : Colors.red),
                        title: Text('\${t.category} • \${t.type}'),
                        subtitle: Text('\${DateTime.fromMillisecondsSinceEpoch(t.timestamp)} • \${t.note}'),
                        trailing: Text('\${t.amount.toStringAsFixed(2)} \${t.currency}'),
                      ),
                    );
                  },
                ),
        )
      ]),
    );
  }
}
