import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:loribudget/services/locale_service.dart';
import 'package:loribudget/providers/finance_provider.dart';
import 'package:loribudget/services/akbank_service.dart';
import 'package:loribudget/services/export_service.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final localeSvc = Provider.of<LocaleService>(context);
    final fp = Provider.of<FinanceProvider>(context, listen: false);
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(LocaleService.t('settings'), style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        Card(
          color: const Color(0xFF0F1113),
          child: ListTile(
            title: Text(LocaleService.t('language')),
            subtitle: const Text('English / Türkçe'),
            trailing: DropdownButton<Locale>(
              value: localeSvc.locale,
              items: const [
                DropdownMenuItem(value: Locale('en'), child: Text('English')),
                DropdownMenuItem(value: Locale('tr'), child: Text('Türkçe')),
              ],
              onChanged: (l) { if (l != null) localeSvc.setLocale(l); },
            ),
          ),
        ),
        const SizedBox(height: 8),
        Card(
          color: const Color(0xFF0F1113),
          child: ListTile(
            title: Text(LocaleService.t('notifications')),
            subtitle: const Text('Bildirim türlerini seçin'),
            trailing: Switch(value: true, onChanged: (v) {/* placeholder */}),
          ),
        ),
        const SizedBox(height: 8),
        Card(
          color: const Color(0xFF0F1113),
          child: ListTile(
            title: Text(LocaleService.t('akbank_import')),
            subtitle: const Text('Otomatik içe aktarma (placeholder)'),
            trailing: ElevatedButton(onPressed: () async {
              final result = await AkbankService.importFromAkbank();
              ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(result)));
            }, child: const Text('İçe Aktar')),
          ),
        ),
        const SizedBox(height: 8),
        Card(
          color: const Color(0xFF0F1113),
          child: ListTile(
            title: Text(LocaleService.t('export')),
            subtitle: const Text('Yerel Excel dosyası kaydet'),
            trailing: ElevatedButton(onPressed: () async {
              final path = await ExportService.exportAllToExcel();
              ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Dışa aktarıldı: \$path')));
            }, child: Text(LocaleService.t('export'))),
          ),
        ),
      ]),
    );
  }
}
