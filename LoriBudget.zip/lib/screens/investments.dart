import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:loribudget/providers/finance_provider.dart';
import 'package:loribudget/models/investment_model.dart';
import 'package:loribudget/services/locale_service.dart';

class InvestmentScreen extends StatefulWidget {
  const InvestmentScreen({Key? key}) : super(key: key);

  @override
  State<InvestmentScreen> createState() => _InvestmentScreenState();
}

class _InvestmentScreenState extends State<InvestmentScreen> {
  final _assetCtrl = TextEditingController();
  final _amountCtrl = TextEditingController();

  @override
  void dispose() {
    _assetCtrl.dispose();
    _amountCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final fp = Provider.of<FinanceProvider>(context);
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(children: [
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Text(LocaleService.t('investments'), style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
          ElevatedButton(onPressed: () => _showAddDialog(context, fp), child: const Text('Ekle'))
        ]),
        const SizedBox(height: 12),
        Expanded(
          child: fp.loading
              ? const Center(child: CircularProgressIndicator())
              : ListView.builder(
                  itemCount: fp.investments.length,
                  itemBuilder: (context, i) {
                    final inv = fp.investments[i];
                    return Card(
                      color: const Color(0xFF0E0F11),
                      child: ListTile(
                        leading: CircleAvatar(child: Text(inv.asset)),
                        title: Text(inv.asset),
                        subtitle: Text('Miktar: \${inv.amount} • \${inv.currency}'),
                        trailing: Text(DateTime.fromMillisecondsSinceEpoch(inv.timestamp).toLocal().toString().split(' ').first),
                      ),
                    );
                  },
                ),
        )
      ]),
    );
  }

  void _showAddDialog(BuildContext context, FinanceProvider fp) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Yatırım Ekle'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: _assetCtrl, decoration: const InputDecoration(labelText: 'Varlık (örn. BTC)')),
          TextField(controller: _amountCtrl, decoration: const InputDecoration(labelText: 'Miktar'), keyboardType: TextInputType.numberWithOptions(decimal: true)),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('İptal')),
          ElevatedButton(
            onPressed: () async {
              final asset = _assetCtrl.text.trim();
              final amount = double.tryParse(_amountCtrl.text.trim()) ?? 0.0;
              if (asset.isEmpty || amount <= 0) return;
              final inv = InvestmentModel(asset: asset, amount: amount, currency: asset, timestamp: DateTime.now().millisecondsSinceEpoch);
              await fp.addInvestment(inv);
              _assetCtrl.clear();
              _amountCtrl.clear();
              Navigator.pop(ctx);
            },
            child: const Text('Ekle'),
          )
        ],
      ),
    );
  }
}
