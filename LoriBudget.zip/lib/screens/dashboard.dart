import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:loribudget/providers/finance_provider.dart';
import 'package:loribudget/services/locale_service.dart';
import 'package:fl_chart/fl_chart.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final fp = Provider.of<FinanceProvider>(context);

    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(LocaleService.t('overview'), style: const TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              _SummaryCard(title: LocaleService.t('income'), amount: fp.totalIncome),
              _SummaryCard(title: LocaleService.t('expense'), amount: fp.totalExpense),
              _SummaryCard(title: 'Bakiye', amount: fp.balance),
            ],
          ),
          const SizedBox(height: 16),
          const Text('Analiz', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
          const SizedBox(height: 8),
          SizedBox(
            height: 180,
            child: Card(
              color: const Color(0xFF121316),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              child: Padding(
                padding: const EdgeInsets.all(12.0),
                child: LineChart(
                  LineChartData(
                    gridData: FlGridData(show: false),
                    titlesData: FlTitlesData(show: false),
                    borderData: FlBorderData(show: false),
                    lineBarsData: [
                      LineChartBarData(spots: [
                        FlSpot(0, fp.totalExpense / (fp.totalIncome + 1)),
                        FlSpot(1, fp.totalExpense / (fp.totalIncome + 1) + 0.1),
                        FlSpot(2, fp.totalExpense / (fp.totalIncome + 1) - 0.05),
                        FlSpot(3, fp.totalExpense / (fp.totalIncome + 1) + 0.2),
                      ], isCurved: true, dotData: FlDotData(show: false)),
                    ],
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(height: 16),
          const Text('Son İşlemler', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
          const SizedBox(height: 8),
          Expanded(
            child: fp.loading
                ? const Center(child: CircularProgressIndicator())
                : ListView.builder(
                    itemCount: fp.transactions.length,
                    itemBuilder: (context, i) {
                      final t = fp.transactions[i];
                      return Card(
                        color: const Color(0xFF0E0F11),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                        child: ListTile(
                          leading: CircleAvatar(child: Text(t.currency)),
                          title: Text('\${t.category} • \${t.type}'),
                          subtitle: Text(t.note),
                          trailing: Text('\${t.amount.toStringAsFixed(2)} \${t.currency}'),
                        ),
                      );
                    },
                  ),
          )
        ],
      ),
    );
  }
}

class _SummaryCard extends StatelessWidget {
  final String title;
  final double amount;
  const _SummaryCard({required this.title, required this.amount, Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Card(
        color: const Color(0xFF111214),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        child: Padding(
          padding: const EdgeInsets.all(12.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title, style: const TextStyle(fontSize: 12)),
              const SizedBox(height: 8),
              Text(amount.toStringAsFixed(2), style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            ],
          ),
        ),
      ),
    );
  }
}
