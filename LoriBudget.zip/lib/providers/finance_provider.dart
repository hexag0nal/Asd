import 'package:flutter/foundation.dart';
import 'package:loribudget/models/transaction_model.dart';
import 'package:loribudget/models/investment_model.dart';
import 'package:loribudget/services/local_db.dart';

class FinanceProvider with ChangeNotifier {
  List<TransactionModel> transactions = [];
  List<InvestmentModel> investments = [];
  bool loading = false;

  FinanceProvider() {
    loadAll();
  }

  Future<void> loadAll() async {
    loading = true;
    notifyListeners();
    transactions = await LocalDb.instance.getAllTransactions();
    investments = await LocalDb.instance.getAllInvestments();
    loading = false;
    notifyListeners();
  }

  Future<void> addTransaction(TransactionModel t) async {
    await LocalDb.instance.insertTransaction(t);
    await loadAll();
  }

  Future<void> addInvestment(InvestmentModel i) async {
    await LocalDb.instance.insertInvestment(i);
    await loadAll();
  }

  double get totalIncome => transactions.where((t) => t.type == 'income').fold(0.0, (p, e) => p + e.amount);
  double get totalExpense => transactions.where((t) => t.type == 'expense').fold(0.0, (p, e) => p + e.amount);
  double get balance => totalIncome - totalExpense;
}
