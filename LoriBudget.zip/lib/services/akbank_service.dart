// Placeholder/mock for Akbank automatic import. Real integration requires Akbank APIs and user consent.
class AkbankService {
  static Future<String> importFromAkbank() async {
    await Future.delayed(const Duration(seconds: 1));
    return 'Akbank içe aktarımı bu prototipte yer tutucudur.';
  }
}
