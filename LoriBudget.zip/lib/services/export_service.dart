import 'dart:io';
import 'package:excel/excel.dart';
import 'package:path_provider/path_provider.dart';
import 'package:loribudget/services/local_db.dart';

class ExportService {
  static Future<String> exportAllToExcel() async {
    final excel = Excel.createExcel();
    final sheet = excel['Transactions'];
    sheet.appendRow(['id', 'type', 'category', 'amount', 'currency', 'note', 'timestamp']);
    final transactions = await LocalDb.instance.getAllTransactions();
    for (var t in transactions) {
      sheet.appendRow([t.id, t.type, t.category, t.amount, t.currency, t.note, DateTime.fromMillisecondsSinceEpoch(t.timestamp).toIso8601String()]);
    }

    final invSheet = excel['Investments'];
    invSheet.appendRow(['id', 'asset', 'amount', 'currency', 'timestamp']);
    final investments = await LocalDb.instance.getAllInvestments();
    for (var i in investments) {
      invSheet.appendRow([i.id, i.asset, i.amount, i.currency, DateTime.fromMillisecondsSinceEpoch(i.timestamp).toIso8601String()]);
    }

    final bytes = excel.encode();
    final docs = await getApplicationDocumentsDirectory();
    final file = File('\${docs.path}/loribudget_export_\${DateTime.now().millisecondsSinceEpoch}.xlsx');
    await file.writeAsBytes(bytes!);
    return file.path;
  }
}
