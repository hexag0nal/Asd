import 'package:flutter/widgets.dart';

class LocaleService with ChangeNotifier {
  // Default locale set to Turkish as requested
  Locale _locale = const Locale('tr');

  Locale get locale => _locale;

  void setLocale(Locale l) {
    _locale = l;
    notifyListeners();
  }

  static String t(String key) {
    const en = {
      'overview': 'Overview',
      'transactions': 'Transactions',
      'investments': 'Investments',
      'settings': 'Settings',
      'income': 'Income',
      'expense': 'Expense',
      'add': 'Add',
      'export': 'Export to Excel',
      'language': 'Language',
      'notifications': 'Notifications',
      'akbank_import': 'Import from Akbank',
      'quick_add': 'Quick Add',
      'category': 'Category',
      'amount': 'Amount',
      'note': 'Note',
      'date': 'Date',
    };
    const tr = {
      'overview': 'Genel Bakış',
      'transactions': 'İşlemler',
      'investments': 'Yatırımlar',
      'settings': 'Ayarlar',
      'income': 'Gelir',
      'expense': 'Gider',
      'add': 'Ekle',
      'export': 'Excel\'e Aktar',
      'language': 'Dil',
      'notifications': 'Bildirimler',
      'akbank_import': 'Akbank\'tan İçe Aktar',
      'quick_add': 'Hızlı Ekle',
      'category': 'Kategori',
      'amount': 'Tutar',
      'note': 'Not',
      'date': 'Tarih',
    };

    // If app locale is Turkish by default, prefer TR, else EN
    final code = WidgetsBinding.instance.window.locale.languageCode;
    if (code == 'tr') return tr[key] ?? key;
    return en[key] ?? key;
  }
}
