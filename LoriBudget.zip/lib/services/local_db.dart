import 'dart:async';
import 'package:path/path.dart';
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';
import 'package:loribudget/models/transaction_model.dart';
import 'package:loribudget/models/investment_model.dart';

class LocalDb {
  LocalDb._privateConstructor();
  static final LocalDb instance = LocalDb._privateConstructor();
  Database? _db;

  Future<void> init() async {
    final docs = await getApplicationDocumentsDirectory();
    final path = join(docs.path, 'loribudget.db');
    _db = await openDatabase(path, version: 1, onCreate: _onCreate);
    final count = Sqflite.firstIntValue(await _db!.rawQuery('SELECT COUNT(*) FROM transactions')) ?? 0;
    if (count == 0) {
      await insertTransaction(TransactionModel(type: 'income', category: 'Part-time', amount: 500.0, currency: 'TRY', note: 'Burs', timestamp: DateTime.now().millisecondsSinceEpoch - 86400000));
      await insertTransaction(TransactionModel(type: 'expense', category: 'Food', amount: 30.0, currency: 'TRY', note: 'Öğle yemeği', timestamp: DateTime.now().millisecondsSinceEpoch));
      await insertInvestment(InvestmentModel(asset: 'BTC', amount: 0.001, currency: 'BTC', timestamp: DateTime.now().millisecondsSinceEpoch));
    }
  }

  Future _onCreate(Database db, int version) async {
    await db.execute('''
      CREATE TABLE transactions(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        type TEXT,
        category TEXT,
        amount REAL,
        currency TEXT,
        note TEXT,
        timestamp INTEGER
      )
    ''');

    await db.execute('''
      CREATE TABLE investments(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        asset TEXT,
        amount REAL,
        currency TEXT,
        timestamp INTEGER
      )
    ''');
  }

  Future<int> insertTransaction(TransactionModel t) async {
    return await _db!.insert('transactions', t.toMap());
  }

  Future<List<TransactionModel>> getAllTransactions() async {
    final rows = await _db!.query('transactions', orderBy: 'timestamp DESC');
    return rows.map((r) => TransactionModel.fromMap(r)).toList();
  }

  Future<int> deleteTransaction(int id) async {
    return await _db!.delete('transactions', where: 'id = ?', whereArgs: [id]);
  }

  Future<int> insertInvestment(InvestmentModel inv) async {
    return await _db!.insert('investments', inv.toMap());
  }

  Future<List<InvestmentModel>> getAllInvestments() async {
    final rows = await _db!.query('investments', orderBy: 'timestamp DESC');
    return rows.map((r) => InvestmentModel.fromMap(r)).toList();
  }
}
